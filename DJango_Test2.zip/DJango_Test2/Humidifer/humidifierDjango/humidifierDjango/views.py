from django.shortcuts import render
from django.http import JsonResponse
from .models import Humidity, Temperature, AirQuality, TimeData  # Assuming correct model names

def fetch_data_view(request):
    humidity_data = list(Humidity.objects.values())
    temperature_data = list(Temperature.objects.values())
    air_quality_data = list(AirQuality.objects.values())
    time_data = list(TimeData.objects.values())
    
    combined_data = {
        'humidity_data': humidity_data,
        'temperature_data': temperature_data,
        'air_quality_data': air_quality_data,
        'time_data': time_data,
    }
    
    return JsonResponse(combined_data)

def index_view(request):
    # Your code to render the index page
    return render(request, 'index.html')
