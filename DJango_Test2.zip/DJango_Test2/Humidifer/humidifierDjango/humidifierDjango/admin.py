from django.contrib import admin
from .models import Humidity, Temperature, AirQuality, TimeData

admin.site.register(Humidity)
admin.site.register(Temperature)
admin.site.register(AirQuality)
admin.site.register(TimeData)